function replaceStrongWithH3(node) {
    if (node.nodeType === 1 && node.tagName === 'STRONG') {
        const h3 = document.createElement('h3');
        h3.style.display='inline';
        while (node.firstChild) {
            h3.appendChild(node.firstChild);
        }
        for (const attr of node.attributes) {
            h3.setAttribute(attr.name, attr.value);
        }
        node.parentNode.replaceChild(h3, node);
    } else {
        for (const child of node.childNodes) {
            replaceStrongWithH3(child);
        }
    }
}

// Initial replacement for existing nodes
replaceStrongWithH3(document.body);

// Setup MutationObserver to handle live changes
const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
            replaceStrongWithH3(node);
        }
    }
});

observer.observe(document.body, { childList: true, subtree: true });
